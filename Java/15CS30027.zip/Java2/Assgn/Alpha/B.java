interface B extends A
{
  void doSomethingMore();
}
