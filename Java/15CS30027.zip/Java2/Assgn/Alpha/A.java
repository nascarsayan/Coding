interface A
{
  void doSomething();
}
